const menu = document.querySelector('.menu')
const men = document.querySelector('.menu-navegacion')


menu.addEventListener('click', ()=>{
    men.classList.toggle("spread")
})

window.addEventListener('click', e =>{
    if(men.classList.contains('spread') 
        && e.target != men && e.target != menu){
        console.log('cerrar')
        men.classList.toggle("spread")
    }
})